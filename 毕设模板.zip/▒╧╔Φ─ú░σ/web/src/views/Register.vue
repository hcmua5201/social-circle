<template>
  <div class="register-container">
    <div class="register-box">
      <h2>用户注册</h2>
      <el-form :model="registerForm" :rules="registerRules" ref="registerForm">
        <el-form-item prop="username">
          <el-input
              v-model="registerForm.username"
              :prefix-icon="User"
              placeholder="请输入用户名">
          </el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input
              v-model="registerForm.password"
              :prefix-icon="Lock"
              type="password"
              placeholder="请输入密码">
          </el-input>
        </el-form-item>
        <el-form-item prop="confirmPassword">
          <el-input
              v-model="registerForm.confirmPassword"
              :prefix-icon="Key"
              type="password"
              placeholder="请确认密码">
          </el-input>
        </el-form-item>
        <el-form-item prop="email">
          <el-input
              v-model="registerForm.email"
              :prefix-icon="Message"
              placeholder="请输入邮箱">
          </el-input>
        </el-form-item>
        <el-form-item prop="gender">
          <el-select v-model="registerForm.gender" placeholder="请选择性别" style="width: 100%">
            <el-option label="男" value="male"></el-option>
            <el-option label="女" value="female"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="age" label="年龄">
          <el-input-number
              label="年龄"
              :prefix-icon="User"
              v-model="registerForm.age"
              placeholder="请输入年龄"
              style="width: 50%"
              controls-position="right">
          </el-input-number>
        </el-form-item>
        <el-form-item prop="phone">
          <el-input
              v-model="registerForm.phone"
              :prefix-icon="Phone"
              placeholder="请输入手机号">
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="handleRegister" :loading="loading" class="register-btn">
            注册
          </el-button>
        </el-form-item>
      </el-form>
      <div class="login-link">
        已有账号？
        <el-button link type="success" @click="goToLogin">返回登录</el-button>
      </div>
    </div>

    <!-- 邮箱验证弹窗 -->
    <el-dialog
        v-model="emailDialogVisible"
        title="邮箱验证"
        width="400px"
        center>
      <el-form :model="emailForm" :rules="emailRules" ref="emailFormRef">
        <el-form-item prop="code">
          <el-input
              v-model="emailForm.code"
              placeholder="请输入邮箱验证码">
            <template #append>
              <el-button
                  :disabled="countdown > 0"
                  @click="sendVerificationCode">
                {{ countdown > 0 ? `${countdown}s后重试` : '获取邮箱验证码' }}
              </el-button>
            </template>
          </el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="emailDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="verifyEmail" :loading="verifying">
            验证
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { User, Lock, Key, Message, Phone } from '@element-plus/icons-vue'
import { register, sendEmailCode, verifyEmailCode } from "../api/api.js"

export default {
  name: 'Register',
  data() {
    const validateConfirmPassword = (rule, value, callback) => {
      if (value !== this.registerForm.password) {
        callback(new Error('两次输入的密码不一致'))
      } else {
        callback()
      }
    }

    const validateEmail = (rule, value, callback) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(value)) {
        callback(new Error('请输入有效的邮箱地址'))
      } else {
        callback()
      }
    }

    const validatePhone = (rule, value, callback) => {
      const phoneRegex = /^1[3-9]\d{9}$/
      if (!phoneRegex.test(value)) {
        callback(new Error('请输入有效的手机号'))
      } else {
        callback()
      }
    }

    return {
      registerForm: {
        username: '',
        password: '',
        confirmPassword: '',
        email: '',
        gender: '',
        age: '',
        phone: ''
      },
      emailForm: {
        code: ''
      },
      // 邮箱验证发送请求状态
      isSending: false,
      emailDialogVisible: false,
      loading: false,
      verifying: false,
      countdown: 0,
      registerRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '请确认密码', trigger: 'blur' },
          { validator: validateConfirmPassword, trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { validator: validateEmail, trigger: 'blur' }
        ],
        gender: [
          { required: true, message: '请选择性别', trigger: 'change' }
        ],
        age: [
          { required: true, message: '请输入年龄', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: validatePhone, trigger: 'blur' }
        ]
      },
      emailRules: {
        code: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { len: 6, message: '验证码长度应为6位', trigger: 'blur' }
        ]
      },
      User,
      Lock,
      Key,
      Message,
      Phone
    }
  },
  methods: {
    handleRegister() {
      this.$refs.registerForm.validate((valid) => {
        if (valid) {
          this.emailDialogVisible = true
        }
      })
    },

    startCountdown() {
      this.countdown = 60
      const timer = setInterval(() => {
        this.countdown--
        if (this.countdown <= 0) {
          clearInterval(timer)
        }
      }, 1000)
    },

    async sendVerificationCode() {
      if (this.isSending) return; // 如果正在发送，直接返回
      this.isSending = true; // 设置为正在发送状态

      try {
        await sendEmailCode({ email: this.registerForm.email });
        this.$message.success('验证码已发送');
        this.startCountdown();
      } catch (error) {
        this.$message.error('发送验证码失败：' + error.message);
      } finally {
        this.isSending = false; // 在请求结束后重置状态位
      }
    },

    async verifyEmail() {
      if (!this.emailForm.code) {
        this.$message.warning('请输入验证码')
        return
      }

      this.verifying = true
      try {
        const verifyResult = await verifyEmailCode({
          email: this.registerForm.email,
          code: this.emailForm.code
        })

        if (verifyResult.code === 200) {
          await this.submitRegistration()
        } else {
          this.$message.error('验证码验证失败')
        }
      } catch (error) {
        this.$message.error('验证失败：' + error.message)
      } finally {
        this.verifying = false
      }
    },

    async submitRegistration() {
      this.loading = true
      try {
        const registrationData = {
          ...this.registerForm,
          role_id: 2,
          created_at: new Date().toISOString()
        }
        delete registrationData.confirmPassword

        const response = await register(registrationData)
        if (response.code === 200) {
          this.$message.success('注册成功')
          this.emailDialogVisible = false
          this.$router.push('/login')
        } else {
          this.$message.error(response.message || '注册失败，请重试')
        }
      } catch (error) {
        this.$message.error('注册出错：' + error.message)
      } finally {
        this.loading = false
      }
    },

    goToLogin() {
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.register-container {
  height: 100vh;
  width: 100vw;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #43cea2, #185a9d);
  overflow: hidden;
}

.register-box {
  width: 400px;
  padding: 40px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 15px;
  box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
  position: relative;
  backdrop-filter: blur(10px);
}

.register-box h2 {
  margin: 0 0 30px;
  padding: 0;
  color: #185a9d;
  text-align: center;
  font-size: 28px;
  font-weight: 600;
  letter-spacing: 1px;
}

.register-box::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(to right, #43cea2, #185a9d);
  border-radius: 15px 15px 0 0;
}

.register-btn {
  width: 100%;
  margin-top: 20px;
  background: linear-gradient(to right, #43cea2, #185a9d);
  border: none;
  height: 44px;
  font-size: 16px;
}

.register-btn:hover {
  background: linear-gradient(to right, #3cb371, #1e90ff);
  transform: translateY(-1px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.login-link {
  margin-top: 20px;
  text-align: center;
  color: #666;
}

:deep(.el-input__wrapper) {
  background: rgba(255, 255, 255, 0.8);
  border: 1px solid #e0e0e0;
  box-shadow: none;
  height: 44px;
}

:deep(.el-input__wrapper:hover) {
  border-color: #43cea2;
}

:deep(.el-input__wrapper.is-focus) {
  border-color: #185a9d;
  box-shadow: 0 0 0 1px #185a9d;
}

:deep(.el-input__inner) {
  height: 42px;
}

:deep(.el-button--link) {
  color: #43cea2;
}

:deep(.el-button--link:hover) {
  color: #185a9d;
}

@media (max-width: 480px) {
  .register-box {
    width: 90%;
    padding: 20px;
    margin: 0 20px;
  }
}

/* 添加输入框动画效果 */
:deep(.el-input__wrapper) {
  transition: all 0.3s ease;
}

:deep(.el-input__wrapper:focus-within) {
  transform: translateY(-2px);
}

/* 添加表单项动画 */
.el-form-item {
  opacity: 0;
  transform: translateY(20px);
  animation: slideUp 0.5s forwards;
}

@keyframes slideUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.el-form-item:nth-child(1) { animation-delay: 0.1s; }
.el-form-item:nth-child(2) { animation-delay: 0.2s; }
.el-form-item:nth-child(3) { animation-delay: 0.3s; }
.el-form-item:nth-child(4) { animation-delay: 0.4s; }

.el-select {
  width: 100%;
}

.el-input-number {
  width: 100%;
}

:deep(.el-input-number .el-input__wrapper) {
  padding-left: 11px;
}

.dialog-footer {
  text-align: right;
  margin-top: 20px;
}
</style>