import {createRouter, createWebHistory} from 'vue-router'
import Login from "../views/Login.vue";
import Register from "../views/Register.vue";
import Home from "../views/Home.vue";
import MainUserInfo from "../components/MainUserInfo.vue";
import Main_success from "../components/Main_success.vue";
import main_myinfo from "../components/main_myinfo.vue";




const routes = createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: '/',
            name: 'Home',
            component: Home,
            children: [
                {
                    path:'/main_success',
                    component: Main_success
                },
                {
                    path:'/main_userinfo',
                    component: MainUserInfo
                },
                {
                    path:'/main_myinfo',
                    component:main_myinfo
                }
            ]
        },
        // {
        //     path: '/about',
        //     name: 'About',
        //     component: About
        // },
        // {
        //     path: '/contact',
        //     name: 'Contact',
        //     component: Contact
        // },
        {
            path: '/login',
            name: 'Login',
            component: Login
        },
        {
            path: '/register',
            name: 'Register',
            component: Register
        },
        // {
        //     path: '/forgot-password',
        //     name: 'ForgotPassword',
        //     component: ForgotPassword
        // },
        // {
        //     path: '/reset-password',
        //     name: 'ResetPassword',
        //     component: ResetPassword
        // },
    ]
})
//路由守卫，全局前置守卫如果localStorage中有login_userinfo，则进入主页/，否则进入登录页/login
routes.beforeEach((to, from, next) => {
    if (to.path === '/login' || to.path === '/register') {
        next()
    } else {
        if (localStorage.getItem('login_userinfo')) {
            next()
        } else {
            next('/login')
        }
    }
})
export default routes
