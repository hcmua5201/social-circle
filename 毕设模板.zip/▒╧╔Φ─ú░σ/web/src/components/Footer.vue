<template>
  <footer class="app-footer">
    <div class="footer-content">
      <p class="copyright">&copy; 2023 My Company. All rights reserved.</p>
    </div>
  </footer>
</template>

<style lang="scss" scoped>
.app-footer {
  background-color: #409EFF;
  color: #fff;
  padding: 16px 0;
  text-align: center;

  .footer-content {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: center;
    align-items: center;

    .copyright {
      font-size: 14px;
      margin: 0;
    }
  }
}
</style>