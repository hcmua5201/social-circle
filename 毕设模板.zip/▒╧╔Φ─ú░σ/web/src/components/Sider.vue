<template>
  <el-menu
      class="side-menu"
      :default-active="activeMenu"
      background-color="#f2f6fc"
      text-color="#333"
      active-text-color="#fff"
      router
      width="200px"
  >
    <el-menu-item index="/main_success">
<!--      element-ui icon 的主页图标 不用i标签-->
      <el-icon >
        <home-filled></home-filled>
      </el-icon>
      <span>首页</span>
    </el-menu-item>
    <el-menu-item index="/main_userinfo">
      <el-icon >
        <user-filled></user-filled>
      </el-icon>
      <span>用户管理</span>
    </el-menu-item>
  </el-menu>
</template>

<script>
import {HomeFilled, UserFilled} from '@element-plus/icons-vue'
export default {
  name: 'SideMenu',
  components: {UserFilled, HomeFilled},
  data() {
    return {
      activeMenu: 'dashboard'
    }
  }
}
</script>

<style lang="scss">
.side-menu {
  height: 100%;
  border-right: none;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
  width: 200px;
  background: linear-gradient(to bottom, #3c8dbc, #2d8cf0);

  .el-menu-item,
  .el-submenu__title {
    height: 50px;
    line-height: 50px;
    color: #fff;
    transition: all 0.3s;
    font-size: 14px;

    &.is-active {
      background-color: #409EFF;
      color: #fff;
    }

    &:hover {
      background-color: lighten(#409EFF, 10%);
      color: #fff;
    }

    i {
      font-size: 18px;
      margin-right: 10px;
    }
  }
}
</style>