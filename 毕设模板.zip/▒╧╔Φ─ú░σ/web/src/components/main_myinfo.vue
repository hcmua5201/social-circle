<template>
  <div class="info-container">
    <el-card class="info-card" style="width: 500px;height: 500px">
      <template #header>
        <div class="card-header">个人信息</div>
      </template>
      <el-form :model="userInfo" :rules="rules" ref="userForm" label-width="80px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="userInfo.username"  disabled></el-input>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
          <el-input v-model.number="userInfo.age"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="userInfo.email"></el-input>
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="userInfo.phone"></el-input>
        </el-form-item>
        <el-form-item class="btn-group">
          <el-button type="primary" style="width: 600px" @click="submitForm">保存修改</el-button>
          <el-button style="margin-left: 0;width: 600px;margin-top: 20px" @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="info-card" style="height: 500px">
      <template #header>
        <div class="card-header">修改密码</div>
      </template>
      <el-form :model="passwordForm" :rules="passwordRules" ref="passwordForm" label-width="100px">
        <el-form-item label="原密码" prop="oldPassword">
          <el-input type="password" v-model="passwordForm.oldPassword"></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="newPassword">
          <el-input type="password" v-model="passwordForm.newPassword"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input type="password" v-model="passwordForm.confirmPassword"></el-input>
        </el-form-item>
        <el-form-item class="btn-group">
          <el-button type="primary" style="width: 600px" @click="changePassword">修改密码</el-button>
          <el-button style="margin-left: 0;width: 600px;margin-top: 20px" @click="resetPasswordForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'MyInfo',
  data() {
    // 验证两次密码是否一致
    const validateConfirmPassword = (rule, value, callback) => {
      if (value !== this.passwordForm.newPassword) {
        callback(new Error('两次输入的密码不一致'));
      } else {
        callback();
      }
    };

    return {
      userInfo: {
        username: '',
        age: '',
        email: '',
        phone: ''
      },
      rules: {
        age: [
          { required: true, message: '请输入年龄', trigger: 'blur' },
          { type: 'number', message: '年龄必须为数字', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '请输入正确的手机号格式', trigger: 'blur' }
        ]
      },
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      passwordRules: {
        oldPassword: [
          { required: true, message: '请输入原密码', trigger: 'blur' },
          { min: 6, message: '密码长度不能小于6位', trigger: 'blur' }
        ],
        newPassword: [
          { required: true, message: '请输入新密码', trigger: 'blur' },
          { min: 6, message: '密码长度不能小于6位', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '请再次输入新密码', trigger: 'blur' },
          { validator: validateConfirmPassword, trigger: 'blur' }
        ]
      }
    };
  },
  created() {
    this.getUserInfo();
  },
  methods: {
    // 获取用户信息
    getUserInfo() {
      // 这里应该调用接口获取用户信息
      // 示例数据

      this.userInfo = {};
      let userinfo = localStorage.getItem('login_userinfo');
      if (userinfo) {
        this.userInfo = JSON.parse(userinfo);
      }else {
        this.$router.push('/login');
      }
    },
    // 提交个人信息表单
    submitForm() {
      this.$refs.userForm.validate((valid) => {
        if (valid) {
          // 这里调用接口提交表单数据
          this.$message.success('个人信息修改成功');
        } else {
          return false;
        }
      });
    },
    // 重置个人信息表单
    resetForm() {
      this.$refs.userForm.resetFields();
      this.getUserInfo();
    },
    // 修改密码
    changePassword() {
      this.$refs.passwordForm.validate((valid) => {
        if (valid) {
          // 这里调用接口修改密码
          this.$message.success('密码修改成功');
          this.resetPasswordForm();
        } else {
          return false;
        }
      });
    },
    // 重置密码表单
    resetPasswordForm() {
      this.$refs.passwordForm.resetFields();
    }
  }
};
</script>

<style scoped>
.info-container {
  display: flex;
  gap: 20px;
  padding: 20px;
  background-color: #f0f2f5;
  min-height: calc(100vh - 60px);
  box-sizing: border-box;
}

.info-card {
  flex: 1;
  margin: 0;
}

.card-header {
  font-size: 16px;
  font-weight: 500;
}

.btn-group {
  text-align: center;
  margin-bottom: 0;
}

:deep(.el-card__header) {
  padding: 15px 20px;
  border-bottom: 1px solid #ebeef5;
}

:deep(.el-card__body) {
  padding: 20px;
}

@media screen and (max-width: 768px) {
  .info-container {
    flex-direction: column;
    padding: 10px;
  }

  .btn-group .el-button {
    width: 100%;
    margin: 5px 0;
  }

  .btn-group .el-button + .el-button {
    margin-left: 0;
  }
}
</style>