package com.example.controller;

import com.example.DTO.EmailRequest;
import com.example.DTO.VerifyCodeRequest;
import com.example.service.impl.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/email")
@CrossOrigin
public class EmailController {
    @Autowired
    private EmailService emailService;

    @PostMapping("/get_code")
    public Result sendVerificationCode(@RequestBody @Valid EmailRequest request) {
        try {
            emailService.sendVerificationCode(request.getEmail());
            return new Result( "验证码已发送",200, null);
        } catch (Exception e) {
            return new Result( "发送验证码失败: " + e.getMessage(),400, null);
        }
    }

    @PostMapping("/verify")
    public Result verifyCode(@RequestBody @Valid VerifyCodeRequest request) {
        System.out.println("前端发送的验证码: ");
        System.out.println(request.getEmail() + " " + request.getCode());
        boolean isValid = emailService.verifyCode(request.getEmail(), request.getCode());
        if (isValid) {
            return new Result( "验证成功",200, null);
        } else {
            return new Result("验证码无效或已过期",400,null );
        }
    }
}
