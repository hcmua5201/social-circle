package com.example.controller;

import com.example.entry.Role;
import com.example.entry.User;
import com.example.service.RoleService;
import com.example.service.UserService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/users")
@CrossOrigin
@Slf4j
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    RoleService roleService;

    @PostMapping("/login")
    public ResponseEntity<Result> login(@RequestBody User user) {

        System.out.println("正在登录----------------------------");
        System.out.println("登录请求参数为: " + user);
        // 校验用户名和密码是否为空
        System.out.println("校验用户名和密码不能为空操作开始-------------------------------");
        if (user.getUsername() == null || user.getPassword() == null) {
            System.out.println("校验用户名或密码不能为空操作失败--------------------------------");
            return ResponseEntity.ok(new Result("用户名或密码不能为空", 400, null));
        }
        System.out.println("校验用户名和密码不能为空操作成功----------------------------------");
        //查询用户名是否存在
        System.out.println("查询用户名是否存在操作开始-------------------------------------");
        User checkUsername = userService.checkUsername(user.getUsername());
        if (checkUsername != null) {
            System.out.println("登录用户名正确存在");
        }else {
            System.out.println("校验用户名不存在操作失败----------登录用户名不存在");
            return ResponseEntity.ok(new Result("用户名不存在", 404, null));
        }
        // 根据用户名和密码查询用户
        User login = userService.login(user.getUsername(), user.getPassword());
        if (login == null) {
            System.out.println("密码错误");
            return ResponseEntity.ok(new Result("密码错误", 401, null));
        }
        // 实现登录逻辑
        Role roleServiceById = roleService.findById(login.getRole_id());
        System.out.println("登录角色信息为: " + roleServiceById);
        login.setRole_name(roleServiceById.getName());
        System.out.println("登录成功,登录用户信息为: " + login);
        return ResponseEntity.ok(new Result("登录成功", 200, login));
    }

    @PostMapping("/register")
    public Result register(@RequestBody User user) {
        System.out.println("正在注册-------------------------");
        System.out.println("注册请求参数为: " + user);
        //校验邮箱是否被注册
        System.out.println("校验邮箱是否被注册操作开始-");
        User checkEmail = userService.checkEmailisRegister(user.getEmail());
        if (checkEmail != null) {
            System.out.println("邮箱已被注册");
            return new Result("邮箱已被注册", 400, null);
        }
        System.out.println("校验邮箱是否被注册操作成功-");
        //校验用户名是否被注册
        System.out.println("校验用户名是否被注册操作开始-");
        User checkUsername = userService.checkUsernameisRegister(user.getUsername());
        if (checkUsername != null) {
            System.out.println("用户名已被注册");
            return new Result("用户名已被注册", 400, null);
        }
        System.out.println("校验用户名是否被注册操作成功-");
        //检查手机号是否被注册
        System.out.println("检查手机号是否被注册操作开始-");
        User checkPhone = userService.checkPhoneisRegister(user.getPhone());
        if (checkPhone != null) {
            System.out.println("手机号已被注册");
            return new Result("手机号已被注册", 400, null);
        }
        System.out.println("检查手机号是否被注册操作成功-");

        // 实现注册逻辑
        //设置时间格式转换
        String timeString = String.valueOf(user.getCreated_at());
        LocalDateTime localDateTime = LocalDateTime.parse(timeString);
        user.setCreated_at(localDateTime);
        System.out.println("注册用户信息为: " + user);
        int userId = userService.createUser(user);
        if (userId <= 0) {
            return new Result("注册失败", 500, null);
        }
        return new Result("注册成功", 200, null);
    }



    @PostMapping("/")
    public ResponseEntity<Result> createUser(@RequestBody User user) {
        int userId = userService.createUser(user);
        user.setId(userId);
        return ResponseEntity.ok(new Result("创建用户成功", 200, user));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Result> deleteUser(@PathVariable int id) {
        int result = userService.deleteUser(id);
        if (result > 0) {
            return ResponseEntity.ok(new Result("删除用户成功", 200, null));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Result("用户不存在", 404, null));
        }
    }

    @GetMapping("/")
    public ResponseEntity<Result> getUsersByPage(@RequestParam(defaultValue = "1") int page,
                                                 @RequestParam(defaultValue = "10") int pageSize) {
        List<User> users = userService.getUsersByPage(page, pageSize);
        return ResponseEntity.ok(new Result("获取用户列表成功", 200, users));
    }

    @GetMapping("/roles")
    public ResponseEntity<Result> getRolesByPage(@RequestParam(defaultValue = "1") int page,
                                                 @RequestParam(defaultValue = "10") int pageSize) {
        List<Role> roles = userService.getRolesByPage(page, pageSize);
        return ResponseEntity.ok(new Result("获取角色列表成功", 200, roles));
    }

    @GetMapping("/search")
    public ResponseEntity<Result> searchUsers(@RequestParam String keyword,
                                              @RequestParam(defaultValue = "1") int page,
                                              @RequestParam(defaultValue = "10") int pageSize) {
        List<User> users = userService.searchUsers(keyword, page, pageSize);
        return ResponseEntity.ok(new Result("搜索用户成功", 200, users));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Result> updateUser(@PathVariable int id, @RequestBody User user) {
        user.setId(id);
        int result = userService.updateUser(user);
        if (result > 0) {
            return ResponseEntity.ok(new Result("更新用户成功", 200, user));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Result("用户不存在", 404, null));
        }
    }
}