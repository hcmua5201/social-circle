package com.example.mapper;

import com.example.entry.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RoleMapper {
    @Select("SELECT * FROM roles")
    List<Role> findAll();

    @Select("SELECT * FROM roles WHERE id = #{id}")
    Role findById(int id);
}