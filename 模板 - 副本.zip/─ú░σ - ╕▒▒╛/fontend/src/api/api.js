//所有axios接口
import axios from 'axios'
axios.defaults.baseURL = '/api'
// 登录接口
export const login = (data) => {
  return axios.post('/users/login', data)
    .then(res => {
        return res.data
    })
    .catch(err => {
        console.log('登录失败',err)
        return err.response.data
    })
}

// 注册接口
export const register = (data) => {
     return axios.post('/users/register', data)
        .then(res => {
             return res.data
        })
        .catch(err => {
             console.log('注册失败',err)
             return err.response.data
        })
}

// 获取邮箱验证码接口
export const sendEmailCode = (data) => {
    return axios.post('/email/get_code', data)
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('获取邮箱验证码失败',err)
            return err.response.data
        })
}

//验证邮箱验证码接口
// 验证邮箱验证码
export const verifyEmailCode = (data) => {
    return axios.post('/email/verify', data)
        .then(res => {
            return res.data
        })
        .catch(err => {
            console.log('验证邮箱验证码失败', err)
            return err.response.data
        })
}


//分页获取所有用户信息接口
export const getUsersByPage = (page, size) => {
    return axios.get('/users/getAllUsersByPage/page=' + page + '&size='+size)
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('分页获取所有用户信息失败',err)
            return err.response.data
        })
}

// 获取所有用户信息接口
// export const getAllUsers = () => {
//     return axios.get('/users')
//        .then(res => {
//             return res.data
//         })
//        .catch(err => {
//             console.log('获取所有用户信息失败',err)
//             return err.response.data
//         })
// }

//根据id获取单个用户信息接口
export const getUserById = (id) => {
    return axios.get('/users/' + id)
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('获取单个用户信息失败',err)
            return err.response.data
        })
}

// editUserInfo编辑用户信息接口
export const editUserInfo = (id, data) => {
    return axios.put('/users/' + id, data)
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('编辑用户信息失败',err)
            return err.response.data
        })
}


// deleteUserInfo删除用户信息接口
export const deleteUserInfo = (id) => {
    return axios.delete('/users/' + id)
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('删除用户信息失败',err)
            return err.response.data
        })
}


//获取搜索角色接口
export const getRoleList = () => {
    return axios.get('/roles', )
       .then(res => {
            return res.data
        })
       .catch(err => {
            console.log('获取搜索角色失败',err)
            return err.response.data
            })
}
