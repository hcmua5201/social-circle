<template>
  <div class="login-container">
    <div class="login-box">
      <h2 class="title">Welcome Login</h2>
      <el-form
          ref="loginFormRef"
          :model="loginForm"
          :rules="loginRules"
          class="login-form"
      >
        <el-form-item prop="username">
          <el-input
              v-model="loginForm.username"
              placeholder="请输入用户名"
              :prefix-icon="User"
              @keyup.enter.native="handleLogin"
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              :prefix-icon="Lock"
              @keyup.enter.native="handleLogin"
          />
        </el-form-item>
        <el-button
            type="primary"
            :loading="loading"
            @click="handleLogin"
            class="login-button"
        >
          登录
        </el-button>
        <div class="register-link">
          <span>没有账号？</span>
          <a href="#" @click.prevent="goToRegister">注册一下</a>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import { User, Lock } from '@element-plus/icons-vue'
import { login } from '../api/api.js'

export default {
  name: 'Login',
  data() {
    return {
      loginForm: {
        username: '',
        password: ''
      },
      loading: false,
      loginRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
        ]
      },
      User,
      Lock
    }
  },
  methods: {
    handleLogin() {
      login(this.loginForm).then((response)=>{
        console.log("登录接口返回数据",response)
        if(response.code === 200){
          this.loading = false
          this.$message.success(response.message)
          localStorage.setItem('login_userinfo', JSON.stringify(response.data))
          this.$router.push('/main_success')
        }else{
          this.loading = false
          this.$message.error(response.message)
        }
      })

    },
    goToRegister() {
      this.$router.push('/register')
    }
  }
}
</script>

<style scoped>
html, body {
  height: 100%;
  margin: 0; /* 去掉边距 */
  padding: 0; /* 去掉填充 */
  box-sizing: border-box; /* 适应 box-sizing */
}

*, *::before, *::after {
  box-sizing: inherit; /* 继承 box-sizing 规则 */
}

.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* 满屏高度 */
  background: linear-gradient(to right, #4776E6, #8E54E9);
}


.login-box {
  width: 400px;
  padding: 40px;
  border-radius: 8px;
  background-color: white;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
  animation: borderAnimation 5s infinite linear;
}

@keyframes borderAnimation {
  0% {
    border: 2px solid #4776E6;
  }
  50% {
    border: 2px solid #8E54E9;
  }
  100% {
    border: 2px solid #4776E6;
  }
}

.title {
  text-align: center;
  margin-bottom: 20px;
  font-weight: bold;
  background: linear-gradient(to right, #4776E6, #8E54E9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.login-form {
  margin-top: 20px;
}

.login-button {
  width: 100%;
  margin-top: 20px;
  background: linear-gradient(to right, #4776E6, #8E54E9);
  border: none;
}

.register-link {
  margin-top: 20px;
  text-align: center;
  color: #999;
}

.register-link a {
  color: #4776E6;
  text-decoration: none;
}

.register-link a:hover {
  color: #8E54E9;
}
</style>
