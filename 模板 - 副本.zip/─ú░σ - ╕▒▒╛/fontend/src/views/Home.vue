<template>
  <div class="home-container">
    <Header />
    <div class="content-wrapper">
      <Sider />
     <router-view></router-view>
    </div>
    <Footer />
  </div>
</template>

<script>
import {defineComponent} from 'vue'
import Header from '../components/Header.vue'
import Sider from '../components/Sider.vue'
import Main_success from '../components/Main_success.vue'
import Footer from '../components/Footer.vue'

export default defineComponent({
  name: 'Home',
  components: {
    Header,
    Sider,
    Main_success,
    Footer
  }
})
</script>

<style scoped>
.home-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.content-wrapper {
  flex: 1;
  display: flex;
}
</style>