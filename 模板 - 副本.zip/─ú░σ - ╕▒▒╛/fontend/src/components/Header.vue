<template>
  <el-header class="app-header">
    <div class="header-content">
      <div class="logo-container">
        <img src="../assets/vue.svg" alt="Logo" class="logo" />
        <span class="logo-text">管理平台</span>
      </div>
      <div class="user-info">
        <el-dropdown>
          <span class="el-dropdown-link">
            <div class="user-details">
              <span class="username">{{ username }}</span>
            </div>
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="gotoMyinfo">个人中心</el-dropdown-item>
              <el-dropdown-item divided @click="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </el-header>
</template>

<script>
import {createRouter as $router} from "vue-router";

export default {
  name: 'Header',
  data() {
    return {
      username: '管理员'
    }
  },
  created() {
    this.getUserInfo();
  },
  methods: {

    getUserInfo() {
      let userinfo = localStorage.getItem('login_userinfo');
      if (userinfo) {
        const { username } = JSON.parse(userinfo);
        this.username = username;
      }else {
        this.$router.push('/login');
      }
    },
    gotoMyinfo() {
      this.$router.push('/main_myinfo');
    },
    logout() {
      localStorage.removeItem('login_userinfo');
      this.$router.push('/login');
    }
  }
}
</script>

<style lang="scss">
.app-header {
  background: linear-gradient(to right, #3c8dbc, #2d8cf0);
  height: 70px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  animation: gradient 10s ease infinite;

  .header-content {
    max-width: 1600px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    color: #fff;
    padding: 0 20px;
  }

  .logo-container {
    display: flex;
    align-items: center;
    flex: 0 0 auto; // 将logo容器设置为自适应宽度
    margin-right: auto; // 将logo容器靠左对齐
  }

  .logo {
    height: 45px;
    margin-right: 15px;
    animation: rotate 10s linear infinite;
  }

  .logo-text {
    font-size: 22px;
    font-weight: bold;
    text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);
  }

  .user-info {
    cursor: pointer;
    display: flex;
    align-items: center;

    .user-details {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      height: 70px;
      justify-content: center;

      .username {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);
      }
    }
  }

  .el-icon-arrow-down {
    margin-left: 10px;
    color: #fff;
    animation: bounce 1s infinite;
  }
}

@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

@keyframes rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  60% {
    transform: translateY(-5px);
  }
}
</style>