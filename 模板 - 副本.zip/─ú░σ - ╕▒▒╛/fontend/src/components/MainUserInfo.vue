<template>
  <el-main class="app-main">
    <div class="content-wrapper">
      <h1>用户管理</h1>

      <!-- 搜索区域 -->
      <div class="search-area">
        <el-form :inline="true" :model="searchForm" class="demo-form-inline">
          <el-form-item label="用户名">
            <el-input
                v-model="searchForm.username"
                placeholder="请输入用户名"
                clearable
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">搜索</el-button>
            <el-button @click="resetSearch">重置</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 表格区域 -->
      <el-table :data="tableData"  border style="width: 100%" v-loading="loading">
<!--        序号列 -->
        <el-table-column type="index" label="序号" width="100" />
<!--        <el-table-column prop="id" label="ID" width="100"  />-->
        <el-table-column prop="username" label="用户名" width="150" />
        <el-table-column prop="age" label="年龄" width="100" />
        <el-table-column prop="email" label="邮箱" width="250" />
        <el-table-column prop="phone" label="电话" width="150" />
        <el-table-column prop="create_at" label="创建时间" width="250" />
        <el-table-column prop="role_id" label="角色" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'danger'">
              {{ scope.row.status === 1 ? '普通用户' : '管理员' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="400">
          <template v-slot="scope">
            <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-container">
        <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="[10, 20, 30, 50]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
        />
      </div>

      <!-- 编辑对话框 -->
      <el-dialog
          v-model="dialogVisible"
          title="编辑用户信息"
          width="500px"
      >
        <el-form
            ref="editFormRef"
            :model="editForm"
            :rules="editRules"
            label-width="100px"
        >
          <el-form-item label="用户名" prop="username">
            <el-input v-model="editForm.username" />
          </el-form-item>
          <el-form-item label="年龄" prop="age">
            <el-input v-model="editForm.age" />
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="editForm.email" />
          </el-form-item>
          <el-form-item label="电话" prop="phone">
            <el-input v-model="editForm.phone" />
          </el-form-item>
          <el-form-item label="角色" prop="role_id">
            <el-select  v-model="editForm.role_id">
              <el-option label="管理员" value="1"></el-option>
              <el-option label="普通用户" value="2"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="submitEdit">
              确定
            </el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </el-main>
</template>

<script>
import { getUsersByPage } from '../api/api.js'
export default {
  name: 'MainUserInfo',
  data() {
    return {
      // 搜索表单
      searchForm: {
        username: ''
      },
      // 表格数据
      tableData: [],
      // 加载状态
      loading: false,
      // 分页相关
      currentPage: 1,
      pageSize: 10,
      total: 0,
      // 对话框显示状态
      dialogVisible: false,
      // 编辑表单
      editForm: {
        id: '',
        username: '',
        age: '',
        email: '',
        phone: '',
        role_id: null
      },
      // 编辑表单验证规则
      editRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入电话', trigger: 'blur' },
          { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    // 获取表格数据
    fetchData() {
      this.loading = true
      // 模拟接口调用

      setTimeout(() => {
        this.test_data = []

        this.tableData = getUsersByPage(this.currentPage, this.pageSize)
        console.log(this.tableData)
        console.log('模拟接口调用成功')
        this.total = this.tableData.length
        this.loading = false
      }, 500)
    },


    // 搜索
    handleSearch() {
      this.currentPage = 1
      this.fetchData()
    },

    // 重置搜索
    resetSearch() {
      this.searchForm.username = ''
      this.handleSearch()
    },

    // 处理分页大小改变
    handleSizeChange(val) {
      this.pageSize = val
      this.fetchData()
    },

    // 处理当前页改变
    handleCurrentChange(val) {
      this.currentPage = val
      this.fetchData()
    },

    // 编辑按钮点击
    handleEdit(row) {
      this.editForm = { ...row }
      this.dialogVisible = true
    },

    // 删除按钮点击
    handleDelete(row) {
      this.$confirm('确认删除该用户?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 调用删除接口
        this.$message.success('删除成功')
        this.fetchData()
      }).catch(() => {
        this.$message.info('已取消删除')
      })
    },

    // 提交编辑
    submitEdit() {
      this.$refs.editFormRef.validate((valid) => {
        if (valid) {
          // 调用更新接口
          this.$message.success('更新成功')
          this.dialogVisible = false
          this.fetchData()
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  background: linear-gradient(to bottom, #f0f2f5, #e6e9ed);
  padding: 30px;

  .content-wrapper {
    max-width: 1400px;
    margin: 0 auto;
    background-color: #fff;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  }

  h1 {
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: bold;
    background: linear-gradient(to right, #4776E6, #8E54E9);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .search-area {
    margin-bottom: 20px;
  }

  .pagination-container {
    margin-top: 20px;
    display: flex;
    justify-content: right;
  }
}

.dialog-footer {
  padding-top: 20px;
  text-align: right;
}
</style>