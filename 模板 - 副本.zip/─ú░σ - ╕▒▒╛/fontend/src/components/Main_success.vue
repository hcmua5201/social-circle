<template>
  <el-main class="app-main">
    <div class="content-wrapper">
      <h1>{{ pageTitle }}</h1>
      <div class="content">
        <!-- 具体页面内容 -->
        success
      </div>
    </div>
  </el-main>
</template>

<script>
export default {
  name: 'Main',
  data() {
    return {
      pageTitle: 'Success Page'
    }
  }
}
</script>

<style lang="scss">
.app-main {
  background: linear-gradient(to bottom, #f0f2f5, #e6e9ed);
  padding: 30px;

  .content-wrapper {
    max-width: 1200px;
    margin: 0 auto;
    background-color: #fff;
    border-radius: 4px;
    padding: 50px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    animation: cardAnimation 5s infinite linear;
  }

  h1 {
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: bold;
    background: linear-gradient(to right, #4776E6, #8E54E9);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}

@keyframes cardAnimation {
  0% {
    box-shadow: 0 2px 12px 0 rgba(71, 118, 230, 0.5);
  }
  50% {
    box-shadow: 0 2px 12px 0 rgba(142, 84, 233, 0.5);
  }
  100% {
    box-shadow: 0 2px 12px 0 rgba(71, 118, 230, 0.5);
  }
}
</style>
