package com.example.config;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class RequestLimitInterceptor implements HandlerInterceptor {

    private static final long TIME_FRAME = 10000; // 10秒
    private static final int MAX_REQUESTS = 3; // 最大请求次数
    private static final long WAIT_TIME = 60000; // 等待时间1分钟

    // 存储请求记录，键为IP地址，值为请求信息
    private final ConcurrentHashMap<String, RequestInfo> requestMap = new ConcurrentHashMap<>();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String clientIp = request.getRemoteAddr(); // 获取客户端IP
        System.out.println("客户端IP：" + clientIp);
        long currentTime = System.currentTimeMillis();
        Date date = new Date(currentTime);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println("当前时间：" + sdf.format(date));


        RequestInfo requestInfo = requestMap.compute(clientIp, (key, info) -> {
            if (info == null) {
                // 首次请求，记录当前时间和次数
                return new RequestInfo(currentTime, 1, false);
            } else if (currentTime - info.timestamp < TIME_FRAME) {
                // 在同一时间段内的请求
                if (info.count >= MAX_REQUESTS) {
                    // 超过最大请求次数，检查是否已等待了一分钟
                    if (currentTime - info.lastBlockTime < WAIT_TIME) {
                        // 还在等待中
                        response.setStatus(429); // 使用状态码429
                        sendErrorMessage(response);
                        return null; // 返回null以阻止后续处理
                    } else {
                        // 重新开始计数
                        info.timestamp = currentTime;
                        info.count = 1;
                    }
                } else {
                    info.count++;
                }
            } else {
                // 超过时间段，重置计数
                info.timestamp = currentTime;
                info.count = 1;
            }
            info.lastBlockTime = currentTime; // 更新最后一次阻止的时间
            return info;
        });

        // 如果返回的requestInfo为null，表示请求被拒绝
        return requestInfo != null;
    }

    private void sendErrorMessage(HttpServletResponse response) {
        try {
            response.getWriter().write("操作频繁，请等待一分钟再请求");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static class RequestInfo {
        long timestamp; // 第一次请求的时间戳
        int count; // 当前请求次数
        long lastBlockTime; // 上次阻止请求的时间戳

        public RequestInfo(long timestamp, int count, boolean isBlocked) {
            this.timestamp = timestamp;
            this.count = count;
            this.lastBlockTime = isBlocked ? System.currentTimeMillis() : 0;
        }
    }
}

