package com.example.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.Random;
import java.util.concurrent.TimeUnit;

// EmailService.java
@Service
@Slf4j
public class EmailService {
    private static final String EMAIL_CODE_PREFIX = "email:code:";
    private static final long CODE_EXPIRE_TIME = 300; // 5分钟 = 300秒

    @Value("${mail.from}")
    private String mailFrom;

    @Value("${mail.subject}")
    private String mailSubject;

    @Value("${mail.template}")
    private String mailTemplate;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    public void sendVerificationCode(String email) {
        try {
            // 生成6位随机验证码
            String verificationCode = generateVerificationCode();
            log.info("验证码：{}", verificationCode);

            // 存储到Redis，设置5分钟过期
            String redisKey = EMAIL_CODE_PREFIX + email;
            redisTemplate.opsForValue().set(redisKey, verificationCode, CODE_EXPIRE_TIME, TimeUnit.SECONDS);

            // 发送邮件
            sendEmail(email, verificationCode);

            log.info("验证码发送成功，接收邮箱：{}", email);
        } catch (Exception e) {
            log.error("发送验证码失败：{}", e.getMessage(), e);
            throw new RuntimeException("发送验证码失败：" + e.getMessage());
        }
    }

    public boolean verifyCode(String email, String code) {
        String redisKey = EMAIL_CODE_PREFIX + email;
        String storedCode = redisTemplate.opsForValue().get(redisKey);

        if (storedCode != null && storedCode.equals(code)) {
            // 验证成功后删除验证码
            redisTemplate.delete(redisKey);
            log.info("验证码验证成功，邮箱：{}", email);
            return true;
        }
        log.info("验证码验证失败，邮箱：{}，输入验证码：{}", email, code);
        return false;
    }

    private String generateVerificationCode() {
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            code.append(random.nextInt(10));
        }
        return code.toString();
    }

    private void sendEmail(String to, String code) {
        MimeMessage message = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(mailFrom);
            helper.setTo(to);
            helper.setSubject(mailSubject);
            helper.setText(String.format(mailTemplate, code));

            mailSender.send(message);
        } catch (MessagingException e) {
            log.error("邮件发送失败：{}", e.getMessage(), e);
            throw new RuntimeException("邮件发送失败：" + e.getMessage());
        }
    }
}
