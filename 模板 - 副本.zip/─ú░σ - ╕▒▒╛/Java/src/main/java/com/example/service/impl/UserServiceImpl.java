package com.example.service.impl;

import com.example.entry.Role;
import com.example.entry.User;
import com.example.mapper.UserMapper;
import com.example.service.UserService;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public User checkUsername(String username) {
        return userMapper.checkUsername(username);
    }

    @Override
    public User login(String username, String password) {
        return userMapper.login(username, password);
    }

    //检查邮箱是否被注册
    @Override
    public User checkEmailisRegister(String email) {
        return userMapper.checkEmailisRegister(email);
    }

    //检查用户名是否被注册
    @Override
    public User checkUsernameisRegister(String username) {
        return userMapper.checkUsernameisRegister(username);
    }

    @Override
    public User checkPhoneisRegister(String phone) {
        return userMapper.checkPhoneisRegister(phone);
    }

    @Override
    public User getUserById(int id) {
        return userMapper.getUserById(id);
    }


    // 分页查询用户列表
    @Override
    public List<User> getUsersByPage(int page, int pageSize) {
        PageHelper.startPage(page, pageSize);
        return userMapper.getUsersByPage();
    }

    @Override
    public List<User> searchUsers(String keyword, int page, int pageSize) {
        int offset = (page - 1) * pageSize;
        return userMapper.searchUsers("%" + keyword + "%", offset, pageSize);
    }

    @Override
    public List<Role> getRolesByPage(int page, int pageSize) {
        int offset = (page - 1) * pageSize;
        return userMapper.getRolesByPage(offset, pageSize);
    }

    @Override
    public int createUser(User user) {
        return userMapper.createUser(user);
    }

    @Override
    public int updateUser(User user) {
        return userMapper.updateUser(user);
    }

    @Override
    public int deleteUser(int id) {
        return userMapper.deleteUser(id);
    }
}