package com.example.service;

import com.example.entry.Role;

import java.util.List;

public interface RoleService {
    List<Role> findAll();
    Role findById(int id);
}
