package com.example.entry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private int id;
    private String username;
    private String password;
    private int role_id;
    private String role_name;
    private int age;
    private String email;
    private String phone;
    private LocalDateTime created_at;
}