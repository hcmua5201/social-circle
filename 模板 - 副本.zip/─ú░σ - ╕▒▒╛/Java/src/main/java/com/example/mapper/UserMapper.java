package com.example.mapper;

import com.example.entry.Role;
import com.example.entry.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {


    //查询登录操作，用户名是否正确
    @Select("SELECT * FROM users WHERE username = #{username}")
    User checkUsername(String username);

    //登录
    @Select("SELECT * FROM users WHERE username = #{username} AND password = #{password}")
    User login(@Param("username") String username, @Param("password") String password);


    //检查邮箱是否被注册
    @Select("SELECT * FROM users WHERE email = #{email}")
    User checkEmailisRegister(@Param("email") String email);

    //检查用户名是否被注册
    @Select("SELECT * FROM users WHERE username = #{username}")
    User checkUsernameisRegister(@Param("username") String username);

    //检查手机号是否被注册
    @Select("SELECT * FROM users WHERE phone = #{phone}")
    User checkPhoneisRegister(@Param("phone") String phone);

    @Select("SELECT u.*, r.name AS role_name FROM users u " +
            "JOIN roles r ON u.role_id = r.id " +
            "WHERE u.id = #{id}")
    User getUserById(int id);


//    @Select("SELECT u.*, r.name AS role_name FROM users u " +
//            "JOIN roles r ON u.role_id = r.id " +
//            "ORDER BY u.id DESC " +
//            "LIMIT #{offset}, #{pageSize}")
//    List<User> getUsersByPage(@Param("offset") int offset, @Param("pageSize") int pageSize);

    //分页查询所有用户。使用的mybatis的内置分页插件，不需要自己实现分页
    @Select("SELECT * FROM users u ,roles r WHERE u.role_id = r.id ")
    List<User> getUsersByPage();

    @Select("SELECT u.*, r.name AS role_name FROM users u " +
            "JOIN roles r ON u.role_id = r.id " +
            "WHERE u.username LIKE #{keyword} " +
            "ORDER BY u.id DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<User> searchUsers(@Param("keyword") String keyword, @Param("offset") int offset, @Param("pageSize") int pageSize);

    @Select("SELECT r.*, (SELECT COUNT(*) FROM users WHERE role_id = r.id) AS user_count " +
            "FROM roles r " +
            "ORDER BY r.id DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<Role> getRolesByPage(@Param("offset") int offset, @Param("pageSize") int pageSize);

    @Insert("INSERT INTO users (username, password, role_id, age, email, phone, created_at) " +
            "VALUES (#{username}, #{password}, #{role_id}, #{age}, #{email}, #{phone},#{created_at})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int createUser(User user);

    @Update("UPDATE users SET username = #{username}, password = #{password}, role_id = #{roleId}, " +
            "age = #{age}, email = #{email}, phone = #{phone} WHERE id = #{id}")
    int updateUser(User user);

    @Delete("DELETE FROM users WHERE id = #{id}")
    int deleteUser(int id);
}