package com.example.service;

import com.example.entry.User;

import java.util.List;



import com.example.entry.Role;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import java.util.List;

public interface UserService {

    User checkUsername(String username);
    User login(String username, String password);

    //检查邮箱是否被注册
    User checkEmailisRegister(@Param("email") String email);

    //检查用户名是否被注册
    User checkUsernameisRegister(@Param("username") String username);

    //检查手机号是否被注册
    User checkPhoneisRegister(@Param("phone") String phone);

    User getUserById(int id);

    //分页查询用户
    List<User> getUsersByPage(int page, int pageSize);
    List<User> searchUsers(String keyword, int page, int pageSize);
    List<Role> getRolesByPage(int page, int pageSize);
    int createUser(User user);
    int updateUser(User user);
    int deleteUser(int id);
}
